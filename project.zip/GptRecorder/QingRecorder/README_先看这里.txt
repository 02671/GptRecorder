﻿轻录屏（Windows x64）
====================

这是一个用于 Windows 10 22H2 / Windows 11 的个人录屏工具项目。界面为中文，录制结果保存在本机，不添加水印。

【先说明】
当前交付环境不是 Windows，无法在这里实际编译、启动、录屏并回放验证，所以这份压缩包是“可构建项目 + 一键构建/运行脚本”，不是已经编译好的 EXE。请在 Windows 电脑上解压后运行 BuildAndRun.bat，它会尝试构建并启动程序。代码和界面已按完整项目组织，但首次运行仍需在你的电脑上完成构建与实际测试。

【最简单的用法】
1. 将压缩包解压到一个普通文件夹中，例如桌面上的“轻录屏”。不要直接在压缩包里运行。
2. 双击 BuildAndRun.bat。
3. 如果电脑没有 .NET 8 SDK，脚本会询问是否用 Windows 的 winget 安装。按提示操作即可；若你的电脑没有 winget，则按窗口提供的网址安装 .NET 8 SDK，然后再次双击脚本。
4. 脚本会下载项目所需的 NuGet 依赖、生成 Windows x64 程序、创建“轻录屏-Windows-x64.zip”发布包，并尝试自动启动程序。
5. 主界面选择“全屏录制”或“区域录制”，检查“系统声音”和“麦克风”，再点击“开始录制”。区域录制时拖动鼠标框选区域，松开鼠标即可确认。
6. 录制开始后主窗口会收起到系统托盘，按 Ctrl + Alt + R 停止并保存；也可点击任务栏右下角托盘图标，选择“停止录制并保存”。
7. 默认保存目录是“视频\轻录屏”。可以在主界面里修改保存位置。

【默认行为】
- 录制主显示器；区域模式支持自定义矩形。
- 输出 MP4（H.264 视频），默认 30 FPS；也可以切换 60 FPS。
- 可同时录制系统播放声音和麦克风声音。
- 优先使用硬件编码（如果设备支持），减少 CPU 编码压力。
- 快捷键：Ctrl + Alt + R 开始/停止；Ctrl + Alt + O 打开保存目录。
- 设置保存于 %AppData%\QingRecorder\settings.json。

【系统要求】
- Windows 10 22H2 或 Windows 11，64 位。
- 首次构建需要 .NET 8 SDK；正式发布目录会自包含 .NET 运行时。
- ScreenRecorderLib 需要 Microsoft Visual C++ 2015–2022 x64 运行库和 Windows Media Foundation。脚本会在检测不到 VC++ 运行库时询问是否通过 winget 安装。
- Windows N/KN 版本若缺少 Media Foundation，需要先安装相应的 Media Feature Pack。
- 录制 4K 或 60 FPS 会比 1080p/30 FPS 占用更多资源、生成更大的文件。

【重要限制】
- 当前版本以主显示器为录制源，不提供多显示器切换菜单。
- 录制系统声音时，捕获的是所选默认播放设备的系统混音，不是单独某个应用的声音。
- 关闭主窗口且正在录制时，程序会留在系统托盘，避免误关导致录制文件未正常收尾。请通过托盘菜单退出。
- 软件不含签名证书，首次运行可能出现 Windows 安全提示。

【出现问题时】
- 如果提示 Media Foundation 不可用：检查是否为 Windows N/KN 版本并安装 Media Feature Pack。
- 如果提示找不到本机媒体/运行库组件：安装 Microsoft Visual C++ 2015–2022 Redistributable x64。
- 如果系统声音没有录进去：先让电脑播放一段声音，确认声音从当前默认输出设备播放，再重新录制。
- 区域选择被取消：按 Esc 可取消，重新点击开始即可重试。
- 请先完成短时间测试录制并播放检查声音，再用于长时间录制。

【项目结构】
- MainWindow.xaml / MainWindow.xaml.cs：中文主界面、录制流程、系统托盘和全局快捷键
- RegionSelectionWindow.cs：区域框选层
- ScreenRecorderLib：Windows 屏幕录制及 Media Foundation 编码组件（MIT 许可）
- BuildAndRun.bat：一键构建并启动

第三方依赖：ScreenRecorderLib 7.0.1（MIT）。详情：https://github.com/sskodje/ScreenRecorderLib

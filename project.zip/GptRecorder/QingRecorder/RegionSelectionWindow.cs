using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using ShapesRectangle = System.Windows.Shapes.Rectangle;
using DrawingRectangle = System.Drawing.Rectangle;
using Forms = System.Windows.Forms;

namespace QingRecorder;

/// <summary>Primary-display rectangle selector. Returns physical pixel coordinates.</summary>
internal sealed class RegionSelectionWindow : Window
{
    private readonly Canvas _canvas;
    private readonly ShapesRectangle _selection;
    private readonly TextBlock _instruction;
    private Point _startPoint;
    private bool _dragging;

    public DrawingRectangle? SelectedArea { get; private set; }

    public RegionSelectionWindow()
    {
        var screen = Forms.Screen.PrimaryScreen ?? throw new InvalidOperationException("没有找到主显示器。");
        var bounds = screen.Bounds;
        var scale = GetDpiScale();

        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        Background = new SolidColorBrush(Color.FromArgb(118, 9, 18, 35));
        ShowInTaskbar = false;
        Topmost = true;
        Cursor = Cursors.Cross;
        WindowStartupLocation = WindowStartupLocation.Manual;
        Left = bounds.Left / scale.X;
        Top = bounds.Top / scale.Y;
        Width = bounds.Width / scale.X;
        Height = bounds.Height / scale.Y;
        Title = "选择录制区域";

        _canvas = new Canvas { Background = Brushes.Transparent, Focusable = true };
        Content = _canvas;
        _selection = new ShapesRectangle
        {
            Stroke = new SolidColorBrush(Color.FromRgb(86, 130, 255)),
            StrokeThickness = 2,
            Fill = new SolidColorBrush(Color.FromArgb(28, 72, 112, 255)),
            Visibility = Visibility.Collapsed,
            IsHitTestVisible = false
        };
        _canvas.Children.Add(_selection);

        var banner = new Border
        {
            Background = new SolidColorBrush(Color.FromArgb(235, 21, 31, 52)),
            CornerRadius = new CornerRadius(10),
            Padding = new Thickness(18, 11, 18, 11),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Top,
            Child = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Children =
                {
                    new TextBlock { Text = "拖动鼠标框选录制区域", Foreground = Brushes.White, FontSize = 14, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,16,0) },
                    new TextBlock { Text = "松开鼠标确认  ·  Esc 取消", Foreground = new SolidColorBrush(Color.FromRgb(190,201,220)), FontSize = 12, VerticalAlignment = VerticalAlignment.Center }
                }
            }
        };
        Canvas.SetLeft(banner, 24);
        Canvas.SetTop(banner, 24);
        _canvas.Children.Add(banner);

        _instruction = new TextBlock
        {
            Text = "至少选择 120 × 80 像素",
            Foreground = Brushes.White,
            FontSize = 12,
            Background = new SolidColorBrush(Color.FromArgb(180, 21, 31, 52)),
            Padding = new Thickness(8, 4, 8, 4),
            Visibility = Visibility.Collapsed,
            IsHitTestVisible = false
        };
        _canvas.Children.Add(_instruction);

        MouseLeftButtonDown += OnMouseDown;
        MouseMove += OnMouseMove;
        MouseLeftButtonUp += OnMouseUp;
        KeyDown += OnKeyDown;
        SourceInitialized += (_, _) =>
        {
            var effectiveDpi = GetDpiScale();
            Left = bounds.Left / effectiveDpi.X;
            Top = bounds.Top / effectiveDpi.Y;
            Width = bounds.Width / effectiveDpi.X;
            Height = bounds.Height / effectiveDpi.Y;
        };
        Loaded += (_, _) => _canvas.Focus();
    }

    private (double X, double Y) GetDpiScale()
    {
        // WPF resolves the effective DPI for this window; the primary display is the selection target.
        var source = PresentationSource.FromVisual(this);
        if (source?.CompositionTarget is not null)
        {
            var matrix = source.CompositionTarget.TransformToDevice;
            return (matrix.M11, matrix.M22);
        }
        return (1, 1);
    }

    private void OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return;
        _startPoint = e.GetPosition(_canvas);
        _dragging = true;
        _selection.Visibility = Visibility.Visible;
        _selection.Width = 0;
        _selection.Height = 0;
        _instruction.Visibility = Visibility.Collapsed;
        CaptureMouse();
        e.Handled = true;
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        if (!_dragging) return;
        var current = e.GetPosition(_canvas);
        var left = Math.Min(_startPoint.X, current.X);
        var top = Math.Min(_startPoint.Y, current.Y);
        var width = Math.Abs(current.X - _startPoint.X);
        var height = Math.Abs(current.Y - _startPoint.Y);
        Canvas.SetLeft(_selection, left);
        Canvas.SetTop(_selection, top);
        _selection.Width = width;
        _selection.Height = height;
        Canvas.SetLeft(_instruction, left);
        Canvas.SetTop(_instruction, Math.Max(0, top - 30));
        _instruction.Text = $"{(int)Math.Round(width * GetDpiScale().X)} × {(int)Math.Round(height * GetDpiScale().Y)} px";
        _instruction.Visibility = Visibility.Visible;
    }

    private void OnMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (!_dragging || e.ChangedButton != MouseButton.Left) return;
        _dragging = false;
        ReleaseMouseCapture();
        var left = Math.Min(_startPoint.X, e.GetPosition(_canvas).X);
        var top = Math.Min(_startPoint.Y, e.GetPosition(_canvas).Y);
        var width = Math.Abs(e.GetPosition(_canvas).X - _startPoint.X);
        var height = Math.Abs(e.GetPosition(_canvas).Y - _startPoint.Y);
        var dpi = GetDpiScale();
        var x = (int)Math.Round(left * dpi.X);
        var y = (int)Math.Round(top * dpi.Y);
        var w = (int)Math.Round(width * dpi.X);
        var h = (int)Math.Round(height * dpi.Y);
        if (w < 120 || h < 80)
        {
            _instruction.Text = "区域太小，请重新框选（至少 120 × 80 px）";
            _instruction.Visibility = Visibility.Visible;
            _selection.Visibility = Visibility.Collapsed;
            e.Handled = true;
            return;
        }
        SelectedArea = new DrawingRectangle(x, y, w, h);
        DialogResult = true;
        e.Handled = true;
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            SelectedArea = null;
            DialogResult = false;
            e.Handled = true;
        }
    }
}

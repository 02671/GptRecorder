using System.Diagnostics;
using DrawingRectangle = System.Drawing.Rectangle;
using MediaColor = System.Windows.Media.Color;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using ScreenRecorderLib;
using Forms = System.Windows.Forms;

namespace QingRecorder;

public partial class MainWindow : Window
{
    private const int HotkeyRecord = 0x2001;
    private const int HotkeyOpenFolder = 0x2002;
    private const int WmHotkey = 0x0312;
    private const uint ModAlt = 0x0001;
    private const uint ModControl = 0x0002;

    private readonly string _appDataDirectory;
    private readonly string _settingsPath;
    private readonly DispatcherTimer _clock;
    private AppSettings _settings;
    private Recorder? _recorder;
    private Forms.NotifyIcon? _trayIcon;
    private Forms.ToolStripMenuItem? _trayRecordItem;
    private HwndSource? _hwndSource;
    private string? _currentFilePath;
    private DateTime _recordingStartedAt;
    private bool _isStarting;
    private bool _isRecording;
    private bool _isStopping;
    private bool _exitAfterStop;
    private bool _allowExit;

    public MainWindow()
    {
        InitializeComponent();
        _appDataDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "QingRecorder");
        _settingsPath = Path.Combine(_appDataDirectory, "settings.json");
        _settings = LoadSettings();
        OutputPathText.Text = _settings.OutputDirectory;
        SystemAudioCheck.IsChecked = _settings.RecordSystemAudio;
        MicrophoneCheck.IsChecked = _settings.RecordMicrophone;
        FullScreenRadio.IsChecked = _settings.CaptureMode != "Region";
        RegionRadio.IsChecked = _settings.CaptureMode == "Region";
        FpsCombo.SelectedIndex = _settings.FrameRate == 60 ? 1 : 0;
        LatestFileText.Text = "最近录制：暂无文件";

        _clock = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _clock.Tick += (_, _) => UpdateRecordingClock();
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        EnsureOutputDirectory();
        InitializeTrayIcon();
        SetStatus("准备就绪", StatusTone.Ready);
    }

    private void MainWindow_SourceInitialized(object? sender, EventArgs e)
    {
        var hwnd = new WindowInteropHelper(this).Handle;
        _hwndSource = HwndSource.FromHwnd(hwnd);
        _hwndSource?.AddHook(WindowMessageHook);

        // If hotkey registration is unavailable, the app remains fully usable through the tray menu.
        RegisterHotKey(hwnd, HotkeyRecord, ModControl | ModAlt, (uint)KeyInterop.VirtualKeyFromKey(System.Windows.Input.Key.R));
        RegisterHotKey(hwnd, HotkeyOpenFolder, ModControl | ModAlt, (uint)KeyInterop.VirtualKeyFromKey(System.Windows.Input.Key.O));
    }

    private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (!_allowExit && (_isRecording || _isStopping || _isStarting))
        {
            e.Cancel = true;
            HideToTray();
            return;
        }

        SaveSettings();
        _clock.Stop();
        if (_hwndSource is not null)
        {
            var hwnd = _hwndSource.Handle;
            UnregisterHotKey(hwnd, HotkeyRecord);
            UnregisterHotKey(hwnd, HotkeyOpenFolder);
            _hwndSource.RemoveHook(WindowMessageHook);
            _hwndSource = null;
        }

        if (_trayIcon is not null)
        {
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            _trayIcon = null;
        }
    }

    private void RecordButton_Click(object sender, RoutedEventArgs e)
    {
        ToggleRecording();
    }

    private async Task StartRecordingAsync()
    {
        if (_isStarting || _isRecording || _isStopping) return;
        _isStarting = true;
        RecordButton.IsEnabled = false;
        RecordButton.Content = "正在准备…";
        RefreshTrayMenu();
        SetStatus("正在准备录制…", StatusTone.Busy);

        try
        {
            var outputDirectory = OutputPathText.Text.Trim();
            if (string.IsNullOrWhiteSpace(outputDirectory))
                outputDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "轻录屏");
            Directory.CreateDirectory(outputDirectory);

            var recordSystemAudio = SystemAudioCheck.IsChecked == true;
            var recordMicrophone = MicrophoneCheck.IsChecked == true;
            if (recordSystemAudio && Recorder.GetSystemAudioDevices(AudioDeviceSource.OutputDevices).Count == 0)
            {
                var answer = MessageBox.Show(this, "没有检测到可用的系统声音输出设备。是否继续录制画面和其他声音？", "轻录屏", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (answer != MessageBoxResult.Yes) return;
                recordSystemAudio = false;
                SystemAudioCheck.IsChecked = false;
            }
            if (recordMicrophone && Recorder.GetSystemAudioDevices(AudioDeviceSource.InputDevices).Count == 0)
            {
                var answer = MessageBox.Show(this, "没有检测到可用的麦克风。是否继续录制画面和其他声音？", "轻录屏", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (answer != MessageBoxResult.Yes) return;
                recordMicrophone = false;
                MicrophoneCheck.IsChecked = false;
            }

            DrawingRectangle? selectedRegion = null;
            if (RegionRadio.IsChecked == true)
            {
                ShowInTaskbar = true;
                WindowState = WindowState.Normal;
                Activate();
                var selector = new RegionSelectionWindow { Owner = this };
                var accepted = selector.ShowDialog();
                if (accepted != true || selector.SelectedArea is null)
                {
                    SetStatus("已取消区域选择", StatusTone.Ready);
                    return;
                }
                selectedRegion = selector.SelectedArea;
            }

            var monitor = Forms.Screen.PrimaryScreen ?? throw new InvalidOperationException("Windows 没有检测到主显示器。");
            var displayBounds = monitor.Bounds;
            var frameWidth = selectedRegion?.Width ?? displayBounds.Width;
            var frameHeight = selectedRegion?.Height ?? displayBounds.Height;
            if (frameWidth % 2 != 0) frameWidth--;
            if (frameHeight % 2 != 0) frameHeight--;
            frameWidth = Math.Max(2, frameWidth);
            frameHeight = Math.Max(2, frameHeight);

            var displaySource = DisplayRecordingSource.MainMonitor;
            if (displaySource is null)
                throw new InvalidOperationException("无法初始化主显示器采集设备。");
            displaySource.RecorderApi = RecorderApi.WindowsGraphicsCapture;
            displaySource.IsCursorCaptureEnabled = true;
            displaySource.IsBorderRequired = false;

            var outputOptions = new OutputOptions
            {
                RecorderMode = RecorderMode.Video,
                OutputFrameSize = new ScreenSize(frameWidth, frameHeight),
                Stretch = StretchMode.Uniform
            };
            if (selectedRegion is not null)
            {
                var rect = selectedRegion.Value;
                outputOptions.SourceRect = new ScreenRect(rect.X, rect.Y, rect.Width, rect.Height);
            }

            var audioSources = new List<AudioSourceBase>();
            if (recordSystemAudio) audioSources.Add(LoopbackAudioSource.Default);
            if (recordMicrophone) audioSources.Add(CaptureAudioSource.Default);

            var audioOptions = new AudioOptions
            {
                IsAudioEnabled = audioSources.Count > 0,
                AudioSources = audioSources,
                Bitrate = AudioBitrate.bitrate_128kbps,
                Channels = AudioChannels.Stereo
            };

            var videoOptions = new VideoEncoderOptions
            {
                Framerate = FpsCombo.SelectedIndex == 1 ? 60 : 30,
                Quality = 80,
                Bitrate = 8_000_000,
                IsHardwareEncodingEnabled = true,
                IsFixedFramerate = false,
                IsThrottlingDisabled = false,
                IsLowLatencyEnabled = false,
                IsMp4FastStartEnabled = true,
                Encoder = new H264VideoEncoder
                {
                    BitrateMode = H264BitrateControlMode.Quality,
                    EncoderProfile = H264Profile.High
                }
            };

            var options = new RecorderOptions
            {
                SourceOptions = new SourceOptions
                {
                    RecordingSources = new List<RecordingSourceBase> { displaySource }
                },
                OutputOptions = outputOptions,
                AudioOptions = audioOptions,
                VideoEncoderOptions = videoOptions,
                MouseOptions = new MouseOptions { IsMousePointerEnabled = true }
            };

            SaveSettings();
            var outputFilePath = Path.Combine(outputDirectory, $"录屏_{DateTime.Now:yyyyMMdd_HHmmss_fff}.mp4");
            _currentFilePath = outputFilePath;
            _recorder = Recorder.CreateRecorder(options);
            _recorder.OnRecordingComplete += Recorder_OnRecordingComplete;
            _recorder.OnRecordingFailed += Recorder_OnRecordingFailed;
            _recorder.OnStatusChanged += Recorder_OnStatusChanged;

            // Minimize before capture, so the control window is not included in the recording.
            await Task.Delay(220);
            HideToTray();
            await Task.Delay(350);
            _recorder.Record(outputFilePath);
            _isRecording = true;
            _isStopping = false;
            _recordingStartedAt = DateTime.Now;
            _clock.Start();
            SetStatus("录制中 · 00:00:00", StatusTone.Recording);
            RefreshTrayMenu();
            _trayIcon?.ShowBalloonTip(1800, "轻录屏已开始", "按 Ctrl + Alt + R 停止录制，或通过系统托盘操作。", Forms.ToolTipIcon.Info);
        }
        catch (Exception ex)
        {
            _isRecording = false;
            _isStopping = false;
            _clock.Stop();
            CleanupRecorder();
            RestoreMainWindow();
            SetStatus("启动失败", StatusTone.Error);
            MessageBox.Show(this,
                "没有成功开始录制。\n\n请检查 Windows 版本、声音设备和媒体组件，然后重试。\n\n详细信息：" + ex.Message,
                "轻录屏", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            _isStarting = false;
            RefreshTrayMenu();
        }
    }

    private void StopRecording(bool exitAfterStop = false)
    {
        if (_recorder is null || !_isRecording || _isStopping) return;
        _isStopping = true;
        _exitAfterStop = exitAfterStop;
        _clock.Stop();
        SetStatus("正在保存视频…", StatusTone.Busy);
        RefreshTrayMenu();
        try
        {
            _recorder.Stop();
        }
        catch (Exception ex)
        {
            _isStopping = false;
            _isRecording = false;
            CleanupRecorder();
            RestoreMainWindow();
            SetStatus("保存时出现问题", StatusTone.Error);
            MessageBox.Show(this, "停止录制时发生错误：\n\n" + ex.Message, "轻录屏", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Recorder_OnRecordingComplete(object? sender, RecordingCompleteEventArgs e)
    {
        var savedPath = string.IsNullOrWhiteSpace(e.FilePath) ? _currentFilePath : e.FilePath;
        Dispatcher.BeginInvoke(new Action(async () =>
        {
            // Let the native callback return before disposing the recorder instance.
            await Task.Delay(150);
            _isRecording = false;
            _isStopping = false;
            _clock.Stop();
            CleanupRecorder();

            if (!string.IsNullOrWhiteSpace(savedPath) && File.Exists(savedPath))
            {
                LatestFileText.Text = "最近录制：" + savedPath;
                SetStatus("录制已保存", StatusTone.Ready);
                _trayIcon?.ShowBalloonTip(2000, "录制已保存", Path.GetFileName(savedPath), Forms.ToolTipIcon.Info);
            }
            else
            {
                SetStatus("录制已结束", StatusTone.Ready);
            }
            RefreshTrayMenu();

            if (_exitAfterStop)
            {
                _allowExit = true;
                Close();
                return;
            }
            RestoreMainWindow();
        }));
    }

    private void Recorder_OnRecordingFailed(object? sender, RecordingFailedEventArgs e)
    {
        var error = e.Error;
        Dispatcher.BeginInvoke(new Action(async () =>
        {
            await Task.Delay(120);
            _clock.Stop();
            _isRecording = false;
            _isStopping = false;
            CleanupRecorder();
            RefreshTrayMenu();
            RestoreMainWindow();
            SetStatus("录制失败", StatusTone.Error);
            MessageBox.Show(this, "录制过程发生错误：\n\n" + error + "\n\n请确认磁盘有足够空间，并检查声音设备或系统媒体组件。", "轻录屏", MessageBoxButton.OK, MessageBoxImage.Warning);
        }));
    }

    private void Recorder_OnStatusChanged(object? sender, RecordingStatusEventArgs e)
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (!_isStopping && e.Status == RecorderStatus.Recording)
            {
                _isRecording = true;
                RefreshTrayMenu();
            }
        }));
    }

    private void UpdateRecordingClock()
    {
        if (!_isRecording || _isStopping) return;
        var elapsed = DateTime.Now - _recordingStartedAt;
        StatusText.Text = $"录制中 · {elapsed:hh\\:mm\\:ss}";
        StatusDot.Fill = new SolidColorBrush(MediaColor.FromRgb(225, 58, 69));
    }

    private void BrowseFolder_Click(object sender, RoutedEventArgs e)
    {
        using var dialog = new Forms.FolderBrowserDialog
        {
            Description = "选择录屏文件保存位置",
            UseDescriptionForTitle = true,
            SelectedPath = Directory.Exists(OutputPathText.Text) ? OutputPathText.Text : Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            ShowNewFolderButton = true
        };
        if (dialog.ShowDialog() == Forms.DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
        {
            OutputPathText.Text = dialog.SelectedPath;
            _settings.OutputDirectory = dialog.SelectedPath;
            EnsureOutputDirectory();
            SaveSettings();
        }
    }

    private void OpenFolder_Click(object sender, RoutedEventArgs e) => OpenOutputFolder();

    private void OpenOutputFolder()
    {
        try
        {
            EnsureOutputDirectory();
            Process.Start(new ProcessStartInfo
            {
                FileName = OutputPathText.Text.Trim(),
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "无法打开保存目录：\n\n" + ex.Message, "轻录屏", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void InitializeTrayIcon()
    {
        if (_trayIcon is not null) return;
        var menu = new Forms.ContextMenuStrip();
        menu.Items.Add("打开轻录屏", null, (_, _) => Dispatcher.BeginInvoke(new Action(RestoreMainWindow)));
        _trayRecordItem = new Forms.ToolStripMenuItem("开始 / 停止录制 (Ctrl+Alt+R)", null, (_, _) => Dispatcher.BeginInvoke(new Action(ToggleRecording)));
        menu.Items.Add(_trayRecordItem);
        menu.Items.Add("打开保存目录 (Ctrl+Alt+O)", null, (_, _) => Dispatcher.BeginInvoke(new Action(OpenOutputFolder)));
        menu.Items.Add(new Forms.ToolStripSeparator());
        menu.Items.Add("退出轻录屏", null, (_, _) => Dispatcher.BeginInvoke(new Action(ExitFromTray)));
        _trayIcon = new Forms.NotifyIcon
        {
            Text = "轻录屏",
            Icon = System.Drawing.SystemIcons.Application,
            Visible = true,
            ContextMenuStrip = menu
        };
        _trayIcon.DoubleClick += (_, _) => Dispatcher.BeginInvoke(new Action(RestoreMainWindow));
        RefreshTrayMenu();
    }

    private void RefreshTrayMenu()
    {
        if (_isStarting)
        {
            RecordButton.Content = "正在准备…";
            RecordButton.IsEnabled = false;
        }
        else if (_isStopping)
        {
            RecordButton.Content = "正在保存…";
            RecordButton.IsEnabled = false;
        }
        else if (_isRecording)
        {
            RecordButton.Content = "■  停止并保存";
            RecordButton.IsEnabled = true;
        }
        else
        {
            RecordButton.Content = "●  开始录制";
            RecordButton.IsEnabled = true;
        }

        if (_trayRecordItem is null) return;
        _trayRecordItem.Text = _isRecording || _isStopping ? "停止录制并保存 (Ctrl+Alt+R)" : "开始录制 (Ctrl+Alt+R)";
        _trayRecordItem.Enabled = !_isStarting && !_isStopping;
    }

    private void ToggleRecording()
    {
        if (_isRecording) StopRecording();
        else if (!_isStarting && !_isStopping) _ = StartRecordingAsync();
    }

    private void ExitFromTray()
    {
        if (_isRecording)
        {
            StopRecording(exitAfterStop: true);
            return;
        }
        if (_isStarting || _isStopping) return;
        _allowExit = true;
        Close();
    }

    private void HideToTray()
    {
        ShowInTaskbar = false;
        WindowState = WindowState.Minimized;
        Hide();
    }

    private void RestoreMainWindow()
    {
        ShowInTaskbar = true;
        if (!IsVisible) Show();
        WindowState = WindowState.Normal;
        Activate();
        if (_isRecording)
            SetStatus("录制中 · 按 Ctrl + Alt + R 停止", StatusTone.Recording);
    }

    private void SetStatus(string message, StatusTone tone)
    {
        StatusText.Text = message;
        switch (tone)
        {
            case StatusTone.Ready:
                StatusDot.Fill = new SolidColorBrush(MediaColor.FromRgb(34, 165, 104));
                StatusText.Foreground = new SolidColorBrush(MediaColor.FromRgb(22, 129, 77));
                break;
            case StatusTone.Recording:
                StatusDot.Fill = new SolidColorBrush(MediaColor.FromRgb(225, 58, 69));
                StatusText.Foreground = new SolidColorBrush(MediaColor.FromRgb(182, 38, 50));
                break;
            case StatusTone.Busy:
                StatusDot.Fill = new SolidColorBrush(MediaColor.FromRgb(232, 156, 35));
                StatusText.Foreground = new SolidColorBrush(MediaColor.FromRgb(153, 96, 10));
                break;
            default:
                StatusDot.Fill = new SolidColorBrush(MediaColor.FromRgb(225, 58, 69));
                StatusText.Foreground = new SolidColorBrush(MediaColor.FromRgb(182, 38, 50));
                break;
        }
    }

    private void EnsureOutputDirectory()
    {
        var path = OutputPathText.Text.Trim();
        if (string.IsNullOrWhiteSpace(path))
        {
            path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "轻录屏");
            OutputPathText.Text = path;
            _settings.OutputDirectory = path;
        }
        Directory.CreateDirectory(path);
    }

    private void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(_appDataDirectory);
            _settings.OutputDirectory = string.IsNullOrWhiteSpace(OutputPathText.Text)
                ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "轻录屏")
                : OutputPathText.Text.Trim();
            _settings.RecordSystemAudio = SystemAudioCheck.IsChecked == true;
            _settings.RecordMicrophone = MicrophoneCheck.IsChecked == true;
            _settings.FrameRate = FpsCombo.SelectedIndex == 1 ? 60 : 30;
            _settings.CaptureMode = RegionRadio.IsChecked == true ? "Region" : "FullScreen";
            File.WriteAllText(_settingsPath, JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch
        {
            // A settings write failure must not prevent recording.
        }
    }

    private AppSettings LoadSettings()
    {
        try
        {
            if (File.Exists(_settingsPath))
            {
                var loaded = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(_settingsPath));
                if (loaded is not null && !string.IsNullOrWhiteSpace(loaded.OutputDirectory)) return loaded;
            }
        }
        catch
        {
            // Restore defaults when settings become malformed.
        }
        return new AppSettings
        {
            OutputDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "轻录屏")
        };
    }

    private void CleanupRecorder()
    {
        try
        {
            if (_recorder is not null)
            {
                _recorder.OnRecordingComplete -= Recorder_OnRecordingComplete;
                _recorder.OnRecordingFailed -= Recorder_OnRecordingFailed;
                _recorder.OnStatusChanged -= Recorder_OnStatusChanged;
                _recorder.Dispose();
                _recorder = null;
            }
        }
        catch
        {
            _recorder = null;
        }
    }

    private IntPtr WindowMessageHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WmHotkey)
        {
            var id = wParam.ToInt32();
            if (id == HotkeyRecord)
            {
                Dispatcher.BeginInvoke(new Action(ToggleRecording));
                handled = true;
            }
            else if (id == HotkeyOpenFolder)
            {
                Dispatcher.BeginInvoke(new Action(OpenOutputFolder));
                handled = true;
            }
        }
        return IntPtr.Zero;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    private enum StatusTone { Ready, Recording, Busy, Error }

    private sealed class AppSettings
    {
        public string OutputDirectory { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "轻录屏");
        public bool RecordSystemAudio { get; set; } = true;
        public bool RecordMicrophone { get; set; } = true;
        public int FrameRate { get; set; } = 30;
        public string CaptureMode { get; set; } = "FullScreen";
    }
}

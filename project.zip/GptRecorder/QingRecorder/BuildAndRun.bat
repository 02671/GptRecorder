﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title 轻录屏 - 构建与启动

set "SDK_URL=https://dotnet.microsoft.com/zh-cn/download/dotnet/8.0"
set "PROJECT=%~dp0QingRecorder.csproj"
set "OUT=%~dp0发布版"
set "ZIP=%~dp0轻录屏-Windows-x64.zip"

echo ===============================================
echo   轻录屏：自动构建并启动 Windows x64 程序
echo ===============================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 goto InstallDotnet

dotnet --list-sdks 2>nul | findstr /B "8." >nul
if errorlevel 1 goto InstallDotnet

goto CheckVCRuntime

:InstallDotnet
echo 未检测到 .NET 8 SDK。构建项目需要此组件，构建后的程序本身会自带 .NET 运行时。
echo.
where winget >nul 2>nul
if errorlevel 1 goto ManualDotnet
choice /C YN /M "是否现在使用 winget 尝试自动安装 .NET 8 SDK"
if errorlevel 2 goto ManualDotnet
winget install --id Microsoft.DotNet.SDK.8 --exact --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto ManualDotnet
set "PATH=%ProgramFiles%\dotnet;%PATH%"
where dotnet >nul 2>nul
if errorlevel 1 goto ManualDotnet
dotnet --list-sdks 2>nul | findstr /B "8." >nul
if errorlevel 1 goto ManualDotnet

goto CheckVCRuntime

:ManualDotnet
echo.
echo 请先安装 .NET 8 SDK：
echo %SDK_URL%
start "" "%SDK_URL%"
echo 安装完成后，关闭此窗口，再次双击 BuildAndRun.bat。
pause
exit /b 1

:CheckVCRuntime
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64" /v Installed 2>nul | findstr "0x1" >nul
if not errorlevel 1 goto Build

echo 未能在系统注册表中确认 VC++ 2015-2022 x64 运行库。
where winget >nul 2>nul
if errorlevel 1 goto Build
choice /C YN /M "是否尝试安装录屏组件需要的 VC++ 运行库"
if errorlevel 2 goto Build
winget install --id "Microsoft.VCRedist.2015+.x64" --exact --accept-source-agreements --accept-package-agreements
if errorlevel 1 echo 运行库安装未成功；稍后如遇组件错误，请从微软官网安装 VC++ 2015-2022 x64 运行库。

:Build
echo.
echo [1/3] 正在还原依赖并构建程序，首次运行需要联网……
if exist "%OUT%" rmdir /s /q "%OUT%"
dotnet publish "%PROJECT%" -c Release -r win-x64 -p:Platform=x64 --self-contained true -p:PublishSingleFile=false -p:PublishTrimmed=false -o "%OUT%"
if errorlevel 1 goto BuildFailed

if not exist "%OUT%\轻录屏.exe" goto BuildFailed

echo.
echo [2/3] 正在生成可备份的发布压缩包……
if exist "%ZIP%" del /q "%ZIP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%OUT%\*' -DestinationPath '%ZIP%' -Force"

 echo.
echo [3/3] 构建成功，正在启动轻录屏……
echo 程序位置：%OUT%\轻录屏.exe
echo 发布压缩包：%ZIP%
start "" "%OUT%\轻录屏.exe"
echo.
echo 若程序没有启动，请查看“发布版”文件夹，并阅读“README_先看这里.txt”。
pause
exit /b 0

:BuildFailed
echo.
echo 构建没有成功。请确认网络正常、.NET 10 SDK 已安装，并重新运行本脚本。
echo 如依然失败，请保留本窗口中的错误信息。
pause
exit /b 1
